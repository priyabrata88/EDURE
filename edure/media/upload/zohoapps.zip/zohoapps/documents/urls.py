from django.conf.urls.defaults import *

# Wiki* URLs
urlpatterns = patterns('documents.views',
(r'^/?$', 'show_index'),
(r'^save_file/?$', 'save_file'),
(r'^v/(?P<did>[0-9]+)/?$', 'view_doc'),
(r'^e_frame/(?P<did>[0-9]+)/?$', 'edit_doc_in_frame'),
(r'^e/(?P<did>[0-9]+)/?$', 'edit_doc'),

(r'^sheet_e/(?P<did>[0-9]+)/?$', 'edit_sheet'),
(r'^sheet_e_frame/(?P<did>[0-9]+)/?$', 'edit_sheet', {'inframe': True}),

(r'^slide_e/(?P<did>[0-9]+)/?$', 'edit_slide'),
(r'^slide_e_frame/(?P<did>[0-9]+)/?$', 'edit_slide', {'inframe': True}),
#(r'^entries/$', 'entries'),
#(r'^refs/$', 'referers'),
#(r'^google/$', 'google'),
#(r'^delete/$', 'delete_all'),
)
