# -*- coding: utf-8 -*-
from django.contrib import admin
from documents.models import *

admin.site.register(Document)
