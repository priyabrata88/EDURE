#!/usr/bin/python
import pycurl

from django.shortcuts import render_to_response
from django.conf import settings
from django.template import RequestContext
from django.http import HttpResponseRedirect,HttpResponse
from django.views.generic.list_detail import object_list

from documents.models import *

def show_index(request):
	"""
	List all documents
	"""
	return object_list(
			request,
			Document.objects.all(),
			paginate_by = 50,
			allow_empty = True,
			template_name = 'show_index.html',
			extra_context = {})

class Bodyfetcher:
	def __init__(self):
		self.contents = ''
	
	def body_callback(self, buf):
		self.contents = self.contents + buf

def view_doc(request, did):
	"""
	Display the document in read-only
	"""
	doc = Document.objects.get(id=did)
	ext = str(doc.file.split('.')[-1])
	fname = str(doc.file.split('/')[-1])
	t = Bodyfetcher()
	
	c = pycurl.Curl()
	c.setopt(c.POST, 1)
	c.setopt(c.URL, "http://export.writer.zoho.com/remotedoc.im?apikey=%s&output=view" % settings.APIKEY)
	c.setopt(c.HTTPPOST, [("content", (c.FORM_FILE, str(doc.file))), ("filename", fname), ("id", str(doc.id)), ("format", ext)])
	c.setopt(c.VERBOSE, 1)
	c.setopt(c.WRITEFUNCTION, t.body_callback)
	c.perform()
	c.close()
	zoho = t.contents
	
	return render_to_response(
		'view_doc.html',
		{'doc': doc, 'zoho': zoho},
		context_instance=RequestContext(request))


def edit_doc(request, did):
	"""
	Display the document in Zoho editor
	"""
	doc = Document.objects.get(id=did)
	ext = str(doc.file.split('.')[-1])
	fname = str(doc.file.split('/')[-1])
	t = Bodyfetcher()

	c = pycurl.Curl()
	c.setopt(c.POST, 1)
	c.setopt(c.URL, "http://export.writer.zoho.com/remotedoc.im?apikey=%s&output=editor" % settings.APIKEY)
	c.setopt(c.HTTPPOST, [("content", (c.FORM_FILE, str(doc.file))), ("filename", fname), ("id", str(doc.id)), ("format", ext), ("saveurl", 'http://localhost:8080/doc/save_file/')])
	c.setopt(c.WRITEFUNCTION, t.body_callback)
	c.perform()
	c.close()
	zoho = t.contents
	
	return render_to_response(
		'edit_doc.html',
		{'doc': doc, 'zoho': zoho},
		context_instance=RequestContext(request))


def edit_doc_in_frame(request, did):
	"""
	Show the document in editor embeded in an iframe
	"""
	doc = Document.objects.get(id=did)
	ext = str(doc.file.split('.')[-1])
	fname = str(doc.file.split('/')[-1])
	t = Bodyfetcher()

	c = pycurl.Curl()
	c.setopt(c.POST, 1)
	c.setopt(c.URL, "http://export.writer.zoho.com/remotedoc.im?apikey=%s&output=id" % settings.APIKEY)
	c.setopt(c.HTTPPOST, [("content", (c.FORM_FILE, str(doc.file))), ("filename", fname), ("id", str(doc.id)), ("format", ext), ("saveurl", 'http://localhost:8080/doc/save_file/')])
	c.setopt(c.WRITEFUNCTION, t.body_callback)
	c.perform()
	c.close()
	zoho = t.contents
	
	return render_to_response(
		'edit_doc_in_frame.html',
		{'doc': doc, 'zoho': zoho},
		context_instance=RequestContext(request))

def save_file(request):
	"""
	Save POSTed file
	"""
	if request.POST:
		data = request.POST.copy()
		doc = Document.objects.get(id=data['id'])
		ext = str(doc.file.split('.')[-1])
		fname = str(doc.file.split('/')[-1])
		
		if fname == data['filename']:
			#ok
			print 'saving file'
			content = request.FILES['content'].read()
			f = open(str(doc.file), 'wb')
			f.write(content)
			f.close()
	return HttpResponse('ok')

####
# sheets
####
class Headerfetcher:
	def __init__(self):
		self.contents = ''
	
	def body_callback(self, buf):
		self.contents = self.contents + buf


def edit_sheet(request, did, inframe=False):
	"""
	Display the sheet in Zoho editor
	"""
	doc = Document.objects.get(id=did)
	ext = str(doc.file.split('.')[-1])
	fname = str(doc.file.split('/')[-1])
	t = Headerfetcher()
	
	c = pycurl.Curl()
	c.setopt(c.POST, 1)
	c.setopt(c.URL, "http://sheet.zoho.com/remotedoc.im?apikey=%s&output=editor" % settings.APIKEY)
	c.setopt(c.HTTPPOST, [("content", (c.FORM_FILE, str(doc.file))), ("filename", fname), ("id", str(doc.id)), ("format", ext), ("saveurl", 'http://localhost:8080/doc/save_file/')])
	c.setopt(c.HEADERFUNCTION, t.body_callback)
	c.perform()
	c.close()
	
	x = t.contents.split('\n')
	for i in x:
		if i.startswith('Location: '):
			zoho = i.replace('Location: ', '').strip()
			if inframe:
				return render_to_response(
					'edit_sheet_in_frame.html',
					{'doc': doc, 'zoho': zoho},
					context_instance=RequestContext(request))
			else:
				return HttpResponseRedirect(zoho)
	
	return HttpResponse('ZohoError :(')

##
# Slides
##


def edit_slide(request, did, inframe=False):
	"""
	Display the slide/presentation in Zoho editor
	"""
	doc = Document.objects.get(id=did)
	ext = str(doc.file.split('.')[-1])
	fname = str(doc.file.split('/')[-1])
	t = Headerfetcher()
	
	c = pycurl.Curl()
	c.setopt(c.POST, 1)
	c.setopt(c.URL, "http://show.zoho.com/remotedoc.im?apikey=%s&output=editor" % settings.APIKEY)
	c.setopt(c.HTTPPOST, [("content", (c.FORM_FILE, str(doc.file))), ("filename", fname), ("id", str(doc.id)), ("format", ext), ("saveurl", 'http://localhost:8080/doc/save_file/')])
	c.setopt(c.HEADERFUNCTION, t.body_callback)
	c.perform()
	c.close()
	
	x = t.contents.split('\n')
	for i in x:
		if i.startswith('Location: '):
			zoho = i.replace('Location: ', '').strip()
			if inframe:
				return render_to_response(
					'edit_slide_in_frame.html',
					{'doc': doc, 'zoho': zoho},
					context_instance=RequestContext(request))
			else:
				return HttpResponseRedirect(zoho)
	
	return HttpResponse('ZohoError :(')
