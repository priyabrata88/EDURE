from django.db import models
from django.conf import settings

class Document(models.Model):
	title = models.CharField(max_length=255, verbose_name='Title')
	description = models.TextField(verbose_name='Description')
	file = models.FilePathField(verbose_name='File', blank=True, null=True, path=settings.MEDIA_ROOT + 'documents/')
	doctype = models.CharField(max_length=10, verbose_name='Type', choices=[('doc', 'Document'), ('sheet', 'Sheet'), ('slide', 'Slides')])
	class Meta:
		verbose_name = 'Document'
		verbose_name_plural = 'Documents'

	def __unicode__(self):
		return self.title
